"""Clean Beijing air-quality data and decompose its daily time series.

The script:
1. Keeps observations from 2014 through 2026 (up to the last date present).
2. Inserts missing calendar days.
3. Fills missing pollutant values with the mean of the preceding/following
   five calendar days. The operation is repeated for long missing runs.
4. Produces an additive annual decomposition for every pollutant.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


POLLUTANTS = ["pm25", "pm10", "o3", "no2", "so2", "co"]
DEFAULT_START = pd.Timestamp("2014-01-01")
DEFAULT_END = pd.Timestamp("2026-12-31")
ANNUAL_PERIOD = 365


def read_air_quality(path: Path) -> pd.DataFrame:
    """Read and normalize the source CSV."""
    data = pd.read_csv(path, skipinitialspace=True)
    data.columns = data.columns.str.strip().str.lower()

    required = {"date", *POLLUTANTS}
    missing_columns = required.difference(data.columns)
    if missing_columns:
        names = ", ".join(sorted(missing_columns))
        raise ValueError(f"Missing required columns: {names}")

    data = data[["date", *POLLUTANTS]].copy()
    data["date"] = pd.to_datetime(data["date"], errors="coerce")
    if data["date"].isna().any():
        bad_rows = data.index[data["date"].isna()].tolist()
        raise ValueError(f"Invalid dates at source rows: {bad_rows}")

    data[POLLUTANTS] = data[POLLUTANTS].apply(
        pd.to_numeric, errors="coerce"
    )

    # Mean aggregation makes duplicate dates deterministic if they occur.
    return (
        data.groupby("date", as_index=True)[POLLUTANTS]
        .mean()
        .sort_index()
    )


def fill_with_neighbor_means(
    data: pd.DataFrame, days_each_side: int = 5
) -> tuple[pd.DataFrame, int]:
    """Fill NaNs using available values in a centered calendar-day window."""
    filled = data.copy()
    window = days_each_side * 2 + 1
    iterations = 0

    while filled.isna().any().any():
        neighborhood_means = filled.rolling(
            window=window, center=True, min_periods=1
        ).mean()
        updated = filled.fillna(neighborhood_means)
        iterations += 1

        if updated.isna().sum().sum() == filled.isna().sum().sum():
            unresolved = updated.columns[updated.isna().any()].tolist()
            raise ValueError(
                "Could not fill missing values for: "
                + ", ".join(unresolved)
            )
        filled = updated

    return filled, iterations


def clean_data(
    source: pd.DataFrame,
    start: pd.Timestamp = DEFAULT_START,
    end: pd.Timestamp = DEFAULT_END,
) -> tuple[pd.DataFrame, dict[str, object]]:
    """Select the requested period, add missing dates, and fill missing data."""
    available_end = source.index.max()
    effective_end = min(end, available_end)
    if effective_end < start:
        raise ValueError("The source contains no data in the requested period.")

    selected = source.loc[
        (source.index >= start) & (source.index <= effective_end)
    ]
    full_index = pd.date_range(start, effective_end, freq="D", name="date")
    missing_dates = full_index.difference(selected.index)
    completed = selected.reindex(full_index)
    missing_values_before = completed.isna().sum()

    filled, iterations = fill_with_neighbor_means(completed)
    report: dict[str, object] = {
        "start": start,
        "end": effective_end,
        "source_end": available_end,
        "rows": len(filled),
        "missing_dates": missing_dates,
        "missing_values_before": missing_values_before,
        "fill_iterations": iterations,
    }
    return filled, report


def decompose_annual_series(
    series: pd.Series, period: int = ANNUAL_PERIOD
) -> pd.DataFrame:
    """Return an additive annual decomposition for a daily series.

    Trend is a centered annual moving average. The seasonal component is the
    mean detrended value for each calendar day (month-day), which naturally
    handles leap years. Residual is observed - trend - seasonal.
    """
    min_periods = min(period, max(2, len(series) // 2))
    trend = series.rolling(
        window=period, center=True, min_periods=min_periods
    ).mean()
    trend = trend.bfill().ffill()

    detrended = series - trend
    calendar_day = series.index.strftime("%m-%d")
    seasonal_pattern = detrended.groupby(calendar_day).mean()
    seasonal_pattern -= seasonal_pattern.mean()
    seasonal = pd.Series(
        calendar_day.map(seasonal_pattern),
        index=series.index,
        dtype=float,
    )
    residual = series - trend - seasonal

    return pd.DataFrame(
        {
            "observed": series,
            "trend": trend,
            "seasonal": seasonal,
            "resid": residual,
        },
        index=series.index,
    )


def decompose_all(data: pd.DataFrame) -> pd.DataFrame:
    """Decompose every pollutant and return a flat-column table."""
    parts = []
    for pollutant in POLLUTANTS:
        component = decompose_annual_series(data[pollutant])
        component.columns = [
            f"{pollutant}_{name}" for name in component.columns
        ]
        parts.append(component)
    return pd.concat(parts, axis=1)


def write_report(report: dict[str, object], output_path: Path) -> None:
    """Write a compact text report describing the cleaning operation."""
    missing_dates = report["missing_dates"]
    missing_counts = report["missing_values_before"]
    lines = [
        f"Processed period: {report['start']:%Y-%m-%d} to "
        f"{report['end']:%Y-%m-%d}",
        f"Last date in source: {report['source_end']:%Y-%m-%d}",
        f"Output rows: {report['rows']}",
        f"Inserted dates: {len(missing_dates)}",
        "Inserted date list: "
        + (
            ", ".join(date.strftime("%Y-%m-%d") for date in missing_dates)
            if len(missing_dates)
            else "None"
        ),
        "Missing values before filling: "
        + ", ".join(
            f"{name}={int(count)}"
            for name, count in missing_counts.items()
        ),
        f"Neighbor-mean fill iterations: {report['fill_iterations']}",
        "Missing values after filling: 0",
        "Decomposition: additive annual cycle (365-day trend and "
        "calendar-day seasonal component)",
    ]
    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Clean and decompose Beijing daily air-quality data."
    )
    parser.add_argument(
        "--input",
        type=Path,
        default=Path("beijing-air-quality.csv"),
    )
    parser.add_argument(
        "--clean-output",
        type=Path,
        default=Path("beijing-air-quality-cleaned.csv"),
    )
    parser.add_argument(
        "--decomposition-output",
        type=Path,
        default=Path("beijing-air-quality-decomposition.csv"),
    )
    parser.add_argument(
        "--report-output",
        type=Path,
        default=Path("preprocessing-report.txt"),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    source = read_air_quality(args.input)
    cleaned, report = clean_data(source)
    decomposition = decompose_all(cleaned)

    cleaned.to_csv(
        args.clean_output,
        index=True,
        date_format="%Y-%m-%d",
        float_format="%.6f",
    )
    decomposition.to_csv(
        args.decomposition_output,
        index=True,
        date_format="%Y-%m-%d",
        float_format="%.6f",
    )
    write_report(report, args.report_output)

    print(f"Cleaned data: {args.clean_output} ({len(cleaned)} rows)")
    print(f"Decomposition: {args.decomposition_output}")
    print(f"Report: {args.report_output}")


if __name__ == "__main__":
    main()
