"""Analyze monthly policy effects from decomposed air-quality data.

Influence value = observed value - seasonal value.

Each policy-month is compared with the same calendar month one year earlier.
For policies starting in 2014, 2014 is used only as the reference year and
effect calculations begin in January 2015. A policy is considered effective
in the first month whose year-over-year influence value falls by at least 5%.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


POLLUTANTS = ["pm25", "pm10", "o3", "no2", "so2", "co"]
POLLUTANT_NAMES = {
    "pm25": "PM2.5",
    "pm10": "PM10",
    "o3": "O3",
    "no2": "NO2",
    "so2": "SO2",
    "co": "CO",
}
POLICY_COLUMNS = ["政策名称", "开始年份", "结束年份"]
EFFECT_THRESHOLD_PERCENT = -5.0


def read_decomposition(path: Path) -> pd.DataFrame:
    """Read decomposition data and validate required columns."""
    data = pd.read_csv(path, skipinitialspace=True)
    data.columns = data.columns.str.strip()

    required = {"date"}
    for pollutant in POLLUTANTS:
        required.update(
            {f"{pollutant}_observed", f"{pollutant}_seasonal"}
        )
    missing = required.difference(data.columns)
    if missing:
        raise ValueError(
            "分解数据缺少必要字段：" + "、".join(sorted(missing))
        )

    data["date"] = pd.to_datetime(data["date"], errors="coerce")
    if data["date"].isna().any():
        rows = (data.index[data["date"].isna()] + 2).tolist()
        raise ValueError(f"分解数据存在无效日期，CSV 行号：{rows}")

    value_columns = sorted(required.difference({"date"}))
    data[value_columns] = data[value_columns].apply(
        pd.to_numeric, errors="coerce"
    )
    if data[value_columns].isna().any().any():
        bad_columns = data[value_columns].columns[
            data[value_columns].isna().any()
        ].tolist()
        raise ValueError(
            "分解数据存在无法转换为数值的内容："
            + "、".join(bad_columns)
        )

    return data.sort_values("date").drop_duplicates("date", keep="last")


def read_policies(path: Path) -> pd.DataFrame:
    """Read the first non-empty worksheet containing the policy columns."""
    workbook = pd.ExcelFile(path)
    for sheet_name in workbook.sheet_names:
        data = pd.read_excel(path, sheet_name=sheet_name)
        data.columns = data.columns.astype(str).str.strip()
        if set(POLICY_COLUMNS).issubset(data.columns):
            policies = data[POLICY_COLUMNS].dropna(how="all").copy()
            break
    else:
        raise ValueError(
            "政策文件中未找到包含“政策名称、开始年份、结束年份”的工作表。"
        )

    policies["政策名称"] = policies["政策名称"].astype(str).str.strip()
    for column in ["开始年份", "结束年份"]:
        policies[column] = pd.to_numeric(
            policies[column], errors="coerce"
        ).astype("Int64")

    invalid = policies[
        policies["开始年份"].isna()
        | policies["结束年份"].isna()
        | (policies["结束年份"] < policies["开始年份"])
    ]
    if not invalid.empty:
        rows = (invalid.index + 2).tolist()
        raise ValueError(f"政策年份无效，Excel 行号：{rows}")

    return policies.reset_index(drop=True)


def calculate_monthly_influence(
    decomposition: pd.DataFrame,
) -> pd.DataFrame:
    """Calculate daily influence values and aggregate them by month."""
    daily = decomposition.set_index("date")
    influence = pd.DataFrame(index=daily.index)

    for pollutant in POLLUTANTS:
        influence[pollutant] = (
            daily[f"{pollutant}_observed"]
            - daily[f"{pollutant}_seasonal"]
        )

    monthly = influence.resample("MS").mean()
    monthly.index.name = "月份"
    return monthly


def analyze_policy_pollutant(
    policy_name: str,
    start_year: int,
    end_year: int,
    pollutant: str,
    monthly: pd.DataFrame,
    threshold: float,
) -> tuple[dict[str, object], pd.DataFrame]:
    """Analyze one pollutant using same-month year-over-year changes."""
    baseline_year = 2014 if start_year == 2014 else start_year - 1
    calculation_start_year = 2015 if start_year == 2014 else start_year
    baseline_values = monthly.loc[
        monthly.index.year == baseline_year, pollutant
    ].dropna()

    base_result: dict[str, object] = {
        "政策名称": policy_name,
        "开始年份": start_year,
        "结束年份": end_year,
        "污染物": POLLUTANT_NAMES[pollutant],
        "基准年份": baseline_year,
        "计算开始年份": calculation_start_year,
        "基准年平均影响值": np.nan,
        "基准年份月份数": len(baseline_values),
        "生效判断阈值(%)": threshold,
        "首次下降5%月份": pd.NaT,
        "生效月变化百分比(%)": np.nan,
        "结束年平均影响值": np.nan,
        "结束年上年同月平均影响值": np.nan,
        "结束年变化百分比(%)": np.nan,
        "结束年可用月份数": 0,
        "结束年是否完整": "否",
        "执行期最大降幅月份": pd.NaT,
        "执行期最大降幅影响值": np.nan,
        "执行期最大降幅变化量": np.nan,
        "执行期最大降幅百分比(%)": np.nan,
        "执行期最大绝对变化月份": pd.NaT,
        "执行期最大绝对变化值": np.nan,
        "执行期最大绝对变化百分比(%)": np.nan,
        "分析状态": "",
    }

    if baseline_values.empty:
        base_result["分析状态"] = "基准年份无数据"
        return base_result, pd.DataFrame()

    base_result["基准年平均影响值"] = float(baseline_values.mean())

    policy_start = pd.Timestamp(calculation_start_year, 1, 1)
    policy_end = pd.Timestamp(end_year, 12, 1)
    period = monthly.loc[
        (monthly.index >= policy_start) & (monthly.index <= policy_end),
        [pollutant],
    ].dropna()
    if period.empty:
        base_result["分析状态"] = "政策执行期无数据"
        return base_result, pd.DataFrame()

    detail = period.rename(columns={pollutant: "月影响值"}).copy()
    previous_year_index = detail.index - pd.DateOffset(years=1)
    detail["上年同月影响值"] = monthly[pollutant].reindex(
        previous_year_index
    ).to_numpy()
    detail = detail.dropna(subset=["上年同月影响值"])
    detail = detail.loc[~np.isclose(detail["上年同月影响值"], 0.0)]
    if detail.empty:
        base_result["分析状态"] = "无可用的上年同月数据"
        return base_result, pd.DataFrame()

    detail["变化量"] = detail["月影响值"] - detail["上年同月影响值"]
    detail["变化百分比(%)"] = (
        detail["变化量"] / detail["上年同月影响值"] * 100.0
    )
    detail["是否下降至少5%"] = np.where(
        detail["变化百分比(%)"] <= threshold, "是", "否"
    )
    detail.insert(0, "污染物", POLLUTANT_NAMES[pollutant])
    detail.insert(0, "政策名称", policy_name)
    detail = detail.reset_index()

    effective = detail[
        detail["变化百分比(%)"] <= threshold
    ]
    if not effective.empty:
        first = effective.iloc[0]
        base_result["首次下降5%月份"] = first["月份"]
        base_result["生效月变化百分比(%)"] = first["变化百分比(%)"]

    end_year_detail = detail[detail["月份"].dt.year == end_year]
    if not end_year_detail.empty:
        base_result["结束年平均影响值"] = float(
            end_year_detail["月影响值"].mean()
        )
        base_result["结束年上年同月平均影响值"] = float(
            end_year_detail["上年同月影响值"].mean()
        )
        base_result["结束年变化百分比(%)"] = float(
            end_year_detail["变化百分比(%)"].mean()
        )
        base_result["结束年可用月份数"] = len(end_year_detail)
        base_result["结束年是否完整"] = (
            "是" if len(end_year_detail) == 12 else "否"
        )

    largest_reduction = detail.loc[
        detail["变化百分比(%)"].idxmin()
    ]
    base_result["执行期最大降幅月份"] = largest_reduction["月份"]
    base_result["执行期最大降幅影响值"] = largest_reduction["月影响值"]
    base_result["执行期最大降幅变化量"] = largest_reduction["变化量"]
    base_result["执行期最大降幅百分比(%)"] = largest_reduction[
        "变化百分比(%)"
    ]

    absolute_change_index = detail["变化量"].abs().idxmax()
    largest_absolute = detail.loc[absolute_change_index]
    base_result["执行期最大绝对变化月份"] = largest_absolute["月份"]
    base_result["执行期最大绝对变化值"] = largest_absolute["变化量"]
    base_result["执行期最大绝对变化百分比(%)"] = largest_absolute[
        "变化百分比(%)"
    ]

    notes = []
    if len(baseline_values) < 12:
        notes.append(f"基准年仅有{len(baseline_values)}个月")
    if start_year == 2014:
        notes.append("2014年作基准，计算从2015-01开始")
    if monthly.index.max() < policy_end:
        notes.append(
            f"执行期数据仅截至{monthly.index.max():%Y-%m}"
        )
    if effective.empty:
        notes.append("执行期内未下降至少5%")
    base_result["分析状态"] = "；".join(notes) if notes else "完成"
    return base_result, detail


def analyze_all(
    policies: pd.DataFrame,
    monthly: pd.DataFrame,
    threshold: float = EFFECT_THRESHOLD_PERCENT,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Analyze all policy-pollutant combinations."""
    summary_rows: list[dict[str, object]] = []
    detail_frames: list[pd.DataFrame] = []

    for policy in policies.itertuples(index=False):
        policy_name = str(getattr(policy, "政策名称"))
        start_year = int(getattr(policy, "开始年份"))
        end_year = int(getattr(policy, "结束年份"))

        for pollutant in POLLUTANTS:
            summary, detail = analyze_policy_pollutant(
                policy_name,
                start_year,
                end_year,
                pollutant,
                monthly,
                threshold,
            )
            summary_rows.append(summary)
            if not detail.empty:
                detail_frames.append(detail)

    summary_data = pd.DataFrame(summary_rows)
    detail_data = (
        pd.concat(detail_frames, ignore_index=True)
        if detail_frames
        else pd.DataFrame(
            columns=[
                "月份",
                "政策名称",
                "污染物",
                "月影响值",
                "上年同月影响值",
                "变化量",
                "变化百分比(%)",
                "是否下降至少5%",
            ]
        )
    )
    return summary_data, detail_data


def monthly_output_table(monthly: pd.DataFrame) -> pd.DataFrame:
    """Build a Chinese-labelled monthly influence table."""
    result = monthly.rename(columns=POLLUTANT_NAMES).reset_index()
    result["月份"] = result["月份"].dt.to_period("M").astype(str)
    return result


def format_workbook(path: Path) -> None:
    """Apply readable formatting to the generated workbook."""
    from openpyxl import load_workbook

    workbook = load_workbook(path)
    header_fill = PatternFill("solid", fgColor="4472C4")
    header_font = Font(color="FFFFFF", bold=True)
    percent_headers = {
        "生效判断阈值(%)",
        "生效月变化百分比(%)",
        "结束年变化百分比(%)",
        "执行期最大降幅百分比(%)",
        "执行期最大绝对变化百分比(%)",
        "变化百分比(%)",
    }
    date_headers = {
        "首次下降5%月份",
        "执行期最大降幅月份",
        "执行期最大绝对变化月份",
        "月份",
    }

    for worksheet in workbook.worksheets:
        worksheet.freeze_panes = "A2"
        worksheet.auto_filter.ref = worksheet.dimensions
        worksheet.row_dimensions[1].height = 28

        headers = {
            cell.value: cell.column for cell in worksheet[1]
        }
        for cell in worksheet[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(
                horizontal="center", vertical="center"
            )

        for header in percent_headers.intersection(headers):
            column = get_column_letter(headers[header])
            for cell in worksheet[column][1:]:
                cell.number_format = '0.00"%"'

        for header in date_headers.intersection(headers):
            column = get_column_letter(headers[header])
            for cell in worksheet[column][1:]:
                if hasattr(cell.value, "year"):
                    cell.number_format = "yyyy-mm"

        for column_cells in worksheet.columns:
            values = [
                str(cell.value) if cell.value is not None else ""
                for cell in column_cells[:200]
            ]
            width = min(max(max(map(len, values)) + 2, 10), 42)
            worksheet.column_dimensions[
                get_column_letter(column_cells[0].column)
            ].width = width

    workbook.save(path)


def write_results(
    output_path: Path,
    summary: pd.DataFrame,
    detail: pd.DataFrame,
    monthly: pd.DataFrame,
) -> None:
    """Write all analysis tables to one Excel workbook."""
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        summary.to_excel(writer, sheet_name="政策影响汇总", index=False)
        detail.to_excel(writer, sheet_name="政策逐月变化", index=False)
        monthly_output_table(monthly).to_excel(
            writer, sheet_name="月均影响值", index=False
        )
    format_workbook(output_path)


def write_visualization_data(
    output_dir: Path,
    summary: pd.DataFrame,
    detail: pd.DataFrame,
) -> None:
    """Export compact, browser-friendly CSV files for the D3 page."""
    output_dir.mkdir(parents=True, exist_ok=True)

    summary_columns = {
        "政策名称": "policy",
        "开始年份": "start_year",
        "结束年份": "end_year",
        "污染物": "pollutant",
        "基准年份": "baseline_year",
        "计算开始年份": "calculation_start_year",
        "基准年平均影响值": "baseline_year_mean",
        "结束年变化百分比(%)": "end_change_pct",
        "首次下降5%月份": "effective_month",
        "生效月变化百分比(%)": "effective_change_pct",
        "执行期最大降幅月份": "max_reduction_month",
        "执行期最大降幅百分比(%)": "max_reduction_pct",
        "分析状态": "status",
    }
    web_summary = summary[list(summary_columns)].rename(
        columns=summary_columns
    )
    for column in ["effective_month", "max_reduction_month"]:
        web_summary[column] = pd.to_datetime(
            web_summary[column], errors="coerce"
        ).dt.strftime("%Y-%m")

    detail_columns = {
        "月份": "month",
        "政策名称": "policy",
        "污染物": "pollutant",
        "月影响值": "influence",
        "上年同月影响值": "previous_year_influence",
        "变化百分比(%)": "change_pct",
        "是否下降至少5%": "reached_threshold",
    }
    web_detail = detail[list(detail_columns)].rename(
        columns=detail_columns
    )
    web_detail["month"] = pd.to_datetime(
        web_detail["month"], errors="coerce"
    ).dt.strftime("%Y-%m")

    web_summary.to_csv(
        output_dir / "policy_summary.csv",
        index=False,
        encoding="utf-8-sig",
        float_format="%.6f",
    )
    web_detail.to_csv(
        output_dir / "policy_monthly.csv",
        index=False,
        encoding="utf-8-sig",
        float_format="%.6f",
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="分析污染物去周期后的月度政策影响。"
    )
    parser.add_argument(
        "--decomposition",
        type=Path,
        default=Path("beijing-air-quality-decomposition.csv"),
        help="时间序列分解 CSV 文件。",
    )
    parser.add_argument(
        "--policies",
        type=Path,
        default=Path("政策信息.xlsx"),
        help="政策信息 Excel 文件。",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("政策影响分析结果.xlsx"),
        help="输出 Excel 文件。",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=EFFECT_THRESHOLD_PERCENT,
        help="政策生效阈值，默认 -5，表示同比下降至少 5%%。",
    )
    parser.add_argument(
        "--web-data-dir",
        type=Path,
        default=Path("visualization-data"),
        help="D3 可视化使用的 CSV 输出目录。",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    decomposition = read_decomposition(args.decomposition)
    policies = read_policies(args.policies)
    monthly = calculate_monthly_influence(decomposition)
    summary, detail = analyze_all(
        policies, monthly, threshold=args.threshold
    )
    write_results(args.output, summary, detail, monthly)
    write_visualization_data(args.web_data_dir, summary, detail)

    completed = ~summary["分析状态"].isin(
        ["基准年份无数据", "政策执行期无数据", "无可用的上年同月数据"]
    )
    print(f"政策数量：{len(policies)}")
    print(f"政策-污染物分析数量：{len(summary)}")
    print(f"具有同比结果的分析数量：{int(completed.sum())}")
    print(f"结果文件：{args.output}")
    print(f"可视化数据目录：{args.web_data_dir}")


if __name__ == "__main__":
    main()
